import mongoose, { Schema, Document } from 'mongoose';

export interface IUser extends Document {
  email: string;
  passwordHash: string;
  status: 'pending' | 'active';
  
  verificationCode: string | null;
  verificationCodeExpiresAt: Date | null;
  
  resetCode: string | null;
  resetCodeExpiresAt: Date | null;
  
  token: string | null;
  tokenExpiresAt: Date | null;
  
  fingerprint: string | null;
  
  createdAt: Date;
  updatedAt: Date;

  verificationAttempts: number; 

  pendingExpiresAt: Date | null;
}

const UserSchema = new Schema<IUser>({
  email: { 
    type: String, 
    required: true, 
    unique: true,
    lowercase: true 
  },
  passwordHash: { type: String, required: true },
  status: { 
    type: String, 
    enum: ['pending', 'active'],
    default: 'pending'
  },
  
  verificationCode: { type: String, default: null },
  verificationCodeExpiresAt: { type: Date, default: null },
  
  resetCode: { type: String, default: null },
  resetCodeExpiresAt: { type: Date, default: null },
  
  token: { type: String, default: null },
  tokenExpiresAt: { type: Date, default: null },
  
  fingerprint: { type: String, default: null },
  
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },

  verificationAttempts: { type: Number, default: 0 },

  pendingExpiresAt: { type: Date, default: null }
}, {
  timestamps: true
});

UserSchema.index({ email: 1 });
UserSchema.index({ token: 1 });
UserSchema.index({ verificationCode: 1 });
UserSchema.index({ resetCode: 1 });
UserSchema.index({ pendingExpiresAt: 1 }, { expireAfterSeconds: 0 }); // Автоматическое удаление записей с истёкшим pendingExpiresAt

export const User = mongoose.model<IUser>('User', UserSchema);